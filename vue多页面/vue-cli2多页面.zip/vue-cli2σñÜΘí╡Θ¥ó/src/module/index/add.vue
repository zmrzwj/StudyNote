<template>
  <div id="add">
    i am add
  </div>
</template>

<script>
export default {
  name: 'add'
}
</script>
