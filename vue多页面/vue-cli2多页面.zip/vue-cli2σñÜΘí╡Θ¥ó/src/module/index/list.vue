<template>
  <div id="list">
    i am list
  </div>
</template>

<script>
export default {
  name: 'list'
}
</script>

<style>
#list {
    display: flex;
}
</style>
