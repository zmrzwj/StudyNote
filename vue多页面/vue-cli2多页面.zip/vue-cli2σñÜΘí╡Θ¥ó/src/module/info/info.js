import Vue from 'vue'
import Info from '../../components/info'

require('assets/b.css')
/* eslint-disable no-new */
new Vue({
  el: '#info',
  components: { Info }
})
