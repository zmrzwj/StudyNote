module.exports = {
    publicPath: './',
    devServer:{
        open:true,
        port:8000,
        host: '127.0.0.1',
        proxy: {
            '/TFJB/*': {
                target: 'http://www.future-ssr.cn:8000',
                changeOrigin: true,
                secure: false
            }
        }
    },
    pages:{
        //其它，7
        index:{
            entry:"src/pages/index/index.js",
            template:'src/pages/index/index.html',
            filename:'index.html',
            title: '阿尔法志愿',
            chunks: ['chunk-vendors', 'chunk-common', 'index']
        },
        // login:{
        //     entry:"src/pages/login/login.js",
        //     template:'src/pages/login/login.html',
        //     filename:'login.html',
        //     title: '登录',
        //     chunks: ['chunk-vendors', 'chunk-common', 'login']
        // },
        // forgetPassword:{
        //     entry:"src/pages/forgetPassword/forgetPassword.js",
        //     template:'src/pages/forgetPassword/forgetPassword.html',
        //     filename:'forgetPassword.html',
        //     title: '重置密码',
        //     chunks: ['chunk-vendors', 'chunk-common', 'forgetPassword']
        // },
        // register:{
        //     entry:"src/pages/register/register.js",
        //     template:'src/pages/register/register.html',
        //     filename:'register.html',
        //     title: '注册',
        //     chunks: ['chunk-vendors', 'chunk-common', 'register']
        // },
        // firstLogin:{
        //     entry:"src/pages/firstLogin/firstLogin.js",
        //     template:'src/pages/firstLogin/firstLogin.html',
        //     filename:'firstLogin.html',
        //     title: '信息登记页面',
        //     chunks: ['chunk-vendors', 'chunk-common', 'firstLogin']
        // },
        // VIPBind:{
        //     entry:"src/pages/VIPBind/VIPBind.js",
        //     template:'src/pages/VIPBind/VIPBind.html',
        //     filename:'VIPBind.html',
        //     title: 'VIP卡绑定',
        //     chunks: ['chunk-vendors', 'chunk-common', 'VIPBind']
        // },
        // userAgreement:{
        //     entry:"src/pages/userAgreement/userAgreement.js",
        //     template:'src/pages/userAgreement/userAgreement.html',
        //     filename:'userAgreement.html',
        //     title: '用户协议',
        //     chunks: ['chunk-vendors', 'chunk-common', 'userAgreement']
        // },

        //我的，8
        myIndex:{
            entry:"src/pages/My/myIndex/myIndex.js",
            template:'src/pages/My/myIndex/myIndex.html',
            filename:'myIndex.html',
            title: '我的',
            chunks: ['chunk-vendors', 'chunk-common', 'myIndex']
        },
        myVolunteerDetail:{
            entry:"src/pages/My/myVolunteerDetail/myVolunteerDetail.js",
            template:'src/pages/My/myVolunteerDetail/myVolunteerDetail.html',
            filename:'myVolunteerDetail.html',
            title: '我的志愿表',
            chunks: ['chunk-vendors', 'chunk-common', 'myVolunteerDetail']
        },
        myVolunteerList:{
            entry:"src/pages/My/myVolunteerList/myVolunteerList.js",
            template:'src/pages/My/myVolunteerList/myVolunteerList.html',
            filename:'myVolunteerList.html',
            title: '志愿表',
            chunks: ['chunk-vendors', 'chunk-common', 'myVolunteerList']
        },
        payIndex:{
            entry:"src/pages/My/payIndex/payIndex.js",
            template:'src/pages/My/payIndex/payIndex.html',
            filename:'payIndex.html',
            title: '确认交易',
            chunks: ['chunk-vendors', 'chunk-common', 'payIndex']
        },
        payError:{
            entry:"src/pages/My/payError/payError.js",
            template:'src/pages/My/payError/payError.html',
            filename:'payError.html',
            title: '付款失败',
            chunks: ['chunk-vendors', 'chunk-common', 'payError']
        },
        paySuccess:{
            entry:"src/pages/My/paySuccess/paySuccess.js",
            template:'src/pages/My/paySuccess/paySuccess.html',
            filename:'paySuccess.html',
            title: '付款成功',
            chunks: ['chunk-vendors', 'chunk-common', 'paySuccess']
        },
        myPermission:{
            entry:"src/pages/My/myPermission/myPermission.js",
            template:'src/pages/My/myPermission/myPermission.html',
            filename:'myPermission.html',
            title: '权限说明',
            chunks: ['chunk-vendors', 'chunk-common', 'myPermission']
        },
        updateVIP:{
            entry:"src/pages/My/updateVIP/updateVIP.js",
            template:'src/pages/My/updateVIP/updateVIP.html',
            filename:'updateVIP.html',
            title: '升级VIP',
            chunks: ['chunk-vendors', 'chunk-common', 'updateVIP']
        },
        updateConfirm:{
            entry:"src/pages/My/updateConfirm/updateConfirm.js",
            template:'src/pages/My/updateConfirm/updateConfirm.html',
            filename:'updateConfirm.html',
            title: '确认升级',
            chunks: ['chunk-vendors', 'chunk-common', 'updateConfirm']
        },



        //比一比，8
        // compareMajor:{
        //     entry:"src/pages/Compare/compareMajor/compareMajor.js",
        //     template:'src/pages/Compare/compareMajor/compareMajor.html',
        //     filename:'compareMajor.html',
        //     title: '比专业',
        //     chunks: ['chunk-vendors', 'chunk-common', 'compareMajor']
        // },
        // compareMajorResult:{
        //     entry:"src/pages/Compare/compareMajorResult/compareMajorResult.js",
        //     template:'src/pages/Compare/compareMajorResult/compareMajorResult.html',
        //     filename:'compareMajorResult.html',
        //     title: '比专业结果',
        //     chunks: ['chunk-vendors', 'chunk-common', 'compareMajorResult']
        // },
        // compareSchool:{
        //     entry:"src/pages/Compare/compareSchool/compareSchool.js",
        //     template:'src/pages/Compare/compareSchool/compareSchool.html',
        //     filename:'compareSchool.html',
        //     title: '比学校',
        //     chunks: ['chunk-vendors', 'chunk-common', 'compareSchool']
        // },
        // compareSchoolResult:{
        //     entry:"src/pages/Compare/compareSchoolResult/compareSchoolResult.js",
        //     template:'src/pages/Compare/compareSchoolResult/compareSchoolResult.html',
        //     filename:'compareSchoolResult.html',
        //     title: '比学校结果',
        //     chunks: ['chunk-vendors', 'chunk-common', 'compareSchoolResult']
        // },
        // iCanMajor:{
        //     entry:"src/pages/Compare/iCanMajor/iCanMajor.js",
        //     template:'src/pages/Compare/iCanMajor/iCanMajor.html',
        //     filename:'iCanMajor.html',
        //     title: '我能上的专业',
        //     chunks: ['chunk-vendors', 'chunk-common', 'iCanMajor']
        // },
        // iCanMajorFilter:{
        //     entry:"src/pages/Compare/iCanMajorFilter/iCanMajorFilter.js",
        //     template:'src/pages/Compare/iCanMajorFilter/iCanMajorFilter.html',
        //     filename:'iCanMajorFilter.html',
        //     title: '我能上的专业过滤条件',
        //     chunks: ['chunk-vendors', 'chunk-common', 'iCanMajorFilter']
        // },
        // iCanSchool:{
        //     entry:"src/pages/Compare/iCanSchool/iCanSchool.js",
        //     template:'src/pages/Compare/iCanSchool/iCanSchool.html',
        //     filename:'iCanSchool.html',
        //     title: '我能上的学校',
        //     chunks: ['chunk-vendors', 'chunk-common', 'iCanSchool']
        // },
        // iCanSchoolFilter:{
        //     entry:"src/pages/Compare/iCanSchoolFilter/iCanSchoolFilter.js",
        //     template:'src/pages/Compare/iCanSchoolFilter/iCanSchoolFilter.html',
        //     filename:'iCanSchoolFilter.html',
        //     title: '我能上的学校过滤条件',
        //     chunks: ['chunk-vendors', 'chunk-common', 'iCanSchoolFilter']
        // },


        // //填一填，6
        AIVolunteerFill:{
            entry:"src/pages/Fill/AIVolunteerFill/AIVolunteerFill.js",
            template:'src/pages/Fill/AIVolunteerFill/AIVolunteerFill.html',
            filename:'AIVolunteerFill.html',
            title: '人工智能填',
            chunks: ['chunk-vendors', 'chunk-common', 'AIVolunteerFill']
        },
        AIVolunteerFillResult:{
            entry:"src/pages/Fill/AIVolunteerFillResult/AIVolunteerFillResult.js",
            template:'src/pages/Fill/AIVolunteerFillResult/AIVolunteerFillResult.html',
            filename:'AIVolunteerFillResult.html',
            title: '',
            chunks: ['chunk-vendors', 'chunk-common', 'AIVolunteerFillResult']
        },
        AIVolunteerFillFilter:{
            entry:"src/pages/Fill/AIVolunteerFillFilter/AIVolunteerFillFilter.js",
            template:'src/pages/Fill/AIVolunteerFillFilter/AIVolunteerFillFilter.html',
            filename:'AIVolunteerFillFilter.html',
            title: '',
            chunks: ['chunk-vendors', 'chunk-common', 'AIVolunteerFillFilter']
        },
        expertIndex:{
            entry:"src/pages/Fill/expertIndex/expertIndex.js",
            template:'src/pages/Fill/expertIndex/expertIndex.html',
            filename:'expertIndex.html',
            title: '预约主页',
            chunks: ['chunk-vendors', 'chunk-common', 'expertIndex']
        },
        expertAppointment:{
            entry:"src/pages/Fill/expertAppointment/expertAppointment.js",
            template:'src/pages/Fill/expertAppointment/expertAppointment.html',
            filename:'expertAppointment.html',
            title: '咨询预约',
            chunks: ['chunk-vendors', 'chunk-common', 'expertAppointment']
        },
        expertAppointmentIntroduction:{
            entry:"src/pages/Fill/expertAppointmentIntroduction/expertAppointmentIntroduction.js",
            template:'src/pages/Fill/expertAppointmentIntroduction/expertAppointmentIntroduction.html',
            filename:'expertAppointmentIntroduction.html',
            title: '一对一志愿服务介绍',
            chunks: ['chunk-vendors', 'chunk-common', 'expertAppointmentIntroduction']
        },
        expertAppointmentPay:{
            entry:"src/pages/Fill/expertAppointmentPay/expertAppointmentPay.js",
            template:'src/pages/Fill/expertAppointmentPay/expertAppointmentPay.html',
            filename:'expertAppointmentPay.html',
            title: '预约支付',
            chunks: ['chunk-vendors', 'chunk-common', 'expertAppointmentPay']
        },
        expertAppointmentSuccess:{
            entry:"src/pages/Fill/expertAppointmentSuccess/expertAppointmentSuccess.js",
            template:'src/pages/Fill/expertAppointmentSuccess/expertAppointmentSuccess.html',
            filename:'expertAppointmentSuccess.html',
            title: '预约成功',
            chunks: ['chunk-vendors', 'chunk-common', 'expertAppointmentSuccess']
        },



        //查一查，10
        // searchIndex:{
        //     entry:"src/pages/Search/searchIndex/searchIndex.js",
        //     template:'src/pages/Search/searchIndex/searchIndex.html',
        //     filename:'searchIndex.html',
        //     title: '查一查主页',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchIndex']
        // },
        // searchMajorIndex:{
        //     entry:"src/pages/Search/searchMajorIndex/searchMajorIndex.js",
        //     template:'src/pages/Search/searchMajorIndex/searchMajorIndex.html',
        //     filename:'searchMajorIndex.html',
        //     title: '查专业主页',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMajorIndex']
        // },
        // searchMajorResult:{
        //     entry:"src/pages/Search/searchMajorResult/searchMajorResult.js",
        //     template:'src/pages/Search/searchMajorResult/searchMajorResult.html',
        //     filename:'searchMajorResult.html',
        //     title: '查专业结果',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMajorResult']
        // },
        // searchMyEnroll:{
        //     entry:"src/pages/Search/searchMyEnroll/searchMyEnroll.js",
        //     template:'src/pages/Search/searchMyEnroll/searchMyEnroll.html',
        //     filename:'searchMyEnroll.html',
        //     title: '查录取',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMyEnroll']
        // },
        // searchMyEnrollResult:{
        //     entry:"src/pages/Search/searchMyEnrollResult/searchMyEnrollResult.js",
        //     template:'src/pages/Search/searchMyEnrollResult/searchMyEnrollResult.html',
        //     filename:'searchMyEnrollResult.html',
        //     title: '录取结果',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMyEnrollResult']
        // },
        // searchMyScore:{
        //     entry:"src/pages/Search/searchMyScore/searchMyScore.js",
        //     template:'src/pages/Search/searchMyScore/searchMyScore.html',
        //     filename:'searchMyScore.html',
        //     title: '查分数',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMyScore']
        // },
        // searchMyScoreResult:{
        //     entry:"src/pages/Search/searchMyScoreResult/searchMyScoreResult.js",
        //     template:'src/pages/Search/searchMyScoreResult/searchMyScoreResult.html',
        //     filename:'searchMyScoreResult.html',
        //     title: '分数结果',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchMyScoreResult']
        // },
        // searchSchoolDetail:{
        //     entry:"src/pages/Search/searchSchoolDetail/searchSchoolDetail.js",
        //     template:'src/pages/Search/searchSchoolDetail/searchSchoolDetail.html',
        //     filename:'searchSchoolDetail.html',
        //     title: '学校详情',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchSchoolDetail']
        // },
        // searchSchoolIndex:{
        //     entry:"src/pages/Search/searchSchoolIndex/searchSchoolIndex.js",
        //     template:'src/pages/Search/searchSchoolIndex/searchSchoolIndex.html',
        //     filename:'searchSchoolIndex.html',
        //     title: '查学校主页',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchSchoolIndex']
        // },
        // searchSchoolList:{
        //     entry:"src/pages/Search/searchSchoolList/searchSchoolList.js",
        //     template:'src/pages/Search/searchSchoolList/searchSchoolList.html',
        //     filename:'searchSchoolList.html',
        //     title: '学校列表',
        //     chunks: ['chunk-vendors', 'chunk-common', 'searchSchoolList']
        // }

    }
}