<template>
    <div  style="text-align: center;">
        <div class="clear" style="display: inline-block;">
            <div class="left" >
                <img :src="logo" style="width: 48px;height: 54px;"/>
            </div>
            <div class="left" style="color: #0183ff;height: 54px;padding: 3px;display: flex;flex-direction: column;">
                <div style="font-size: 20px;" class="justify-content_flex-justify">阿 尔 法 志 愿</div>
                <div style="font-size: 11px;">ALPHA VOLUNTEER</div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "head-logo",
        data(){
            return {
                logo:require('../assets/login/login-logo.png')
            }
        }
    }
</script>

<style scoped>
    .left{
        float: left;
    }

    .clear:after{
        content: " ";
        display: block;
        clear: both;
    }
</style>