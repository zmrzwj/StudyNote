<template>
    <div>
        <div style="padding:10px 13px;">
            <div @click="goBack" style="float: left;color:#0099ff;">
                <van-icon name="arrow-left" />
            </div>
            <div style="text-align: center;font-size: 17px;color: #333333;">{{title}}</div>
        </div>

    </div>
</template>

<script>
    export default {
        name: "back-head",
        props:["title"],
        data(){
            return {

            }
        },
        methods:{
            goBack(){
                window.history.go(-1);
            }
        }

    }
</script>

<style scoped>

</style>