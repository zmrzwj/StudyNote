<template>
    <div class="paySuccess" style="display: flex;justify-content: center;align-items: center;flex-direction: column;">
        <div>
            <img :src="successImg" style="width: 120px;height: 120px;"/>
        </div>
        <div style="padding: 10px 0;color: #666666;font-size: 18px;">
            支付成功，{{time}}秒后将跳转至个人中心
        </div>
        <div>
            <div style="margin: 25px 0;">
                <a href="myIndex.html">
                    <div class="button green">立即跳转</div>
                </a>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "paySuccess",
        data(){
            return {
                time:5,
                successImg:require("../../../assets/my/pay/success.png")
            }
        },
        mounted(){
            let _this =this;
            window.setInterval(function(){
                _this.time = _this.time - 1;
                if(_this.time === 0){
                    window.location.href = "myIndex.html";
                }
            },1000)
        }
    }
</script>

<style scoped>
    .paySuccess{
        width: 100%;
        height: 100%;
    }

    .button{
        padding: 10px 40px;
        border-radius: 6px;
    }

    .green{
        background: #00cc00;
        color: white;
    }

    a{
        text-decoration: none;
    }
</style>