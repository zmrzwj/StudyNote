<template>
    <div class="payError" style="display: flex;justify-content: center;align-items: center;flex-direction: column;">
        <div>
            <img :src="errorImg" style="width: 120px;height: 120px;"/>
        </div>
        <div style="padding: 10px 0;color: #666666;font-size: 18px;">
            支付失败或超时
        </div>
        <div>
            <div style="margin: 25px 0;">
                <a href="updateVIP.html">
                    <div class="button green">重新支付</div>
                </a>
            </div>
            <div>
                <a href="index.html">
                    <div class="button blue">返回主页</div>
                </a>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "payError",
        data(){
            return {
                errorImg:require("../../../assets/my/pay/errorHead.png")
            }
        }
    }
</script>

<style scoped>
    .payError{
        width:100%;
        height: 100%;
    }

    .button{
        padding: 10px 40px;
        border-radius: 6px;
    }

    .green{
        background: #00cc00;
        color: white;
    }

    .blue{
        background: #3399ff;
        color: white;
    }

    a{
        text-decoration: none;
    }
</style>