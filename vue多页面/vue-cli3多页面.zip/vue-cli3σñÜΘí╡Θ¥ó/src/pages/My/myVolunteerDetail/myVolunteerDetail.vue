<template>
    <div>
        <div style="padding-bottom: 25px;" >
            <div class="title" @click="changeDownUp()">
                <span style="padding:0 5px">本科提前批</span><a-icon :type="showDetail?'up':'down'"></a-icon>
            </div>
            <div v-show="showDetail">
                <div>
                    <div class="volunteer-list-title" style="display: flex;">
                        <div style="flex: 1;">第一志愿</div>
                        <div style="flex: 1;">北京大学</div>
                        <div style="flex: 1;">10001</div>
                    </div>
                    <div style="display: flex;" class="volunteer-list-major">
                        <div style="width: 50%;display: flex;margin-right: 10px" class="volunteer-list-major-wrap">
                            <div style="width: 30px">01</div>
                            <div style="flex: 1">农学</div>
                            <div style="flex: 1">010101</div>
                        </div>
                        <div style="width: 50%;display: flex;margin-left: 10px;" class="volunteer-list-major-wrap">
                            <div style="width: 30px">01</div>
                            <div style="flex: 1">农学</div>
                            <div style="flex: 1">010101</div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="volunteer-list-title" style="display: flex;">
                        <div style="flex: 1;">第一志愿</div>
                        <div style="flex: 1;">北京大学</div>
                        <div style="flex: 1;">10001</div>
                    </div>
                    <div style="display: flex;" class="volunteer-list-major">
                        <div style="width: 50%;display: flex;margin-right: 10px" class="volunteer-list-major-wrap">
                            <div style="width: 30px">01</div>
                            <div style="flex: 1">农学</div>
                            <div style="flex: 1">010101</div>
                        </div>
                        <div style="width: 50%;display: flex;margin-left: 10px;" class="volunteer-list-major-wrap">
                            <div style="width: 30px">01</div>
                            <div style="flex: 1">农学</div>
                            <div style="flex: 1">010101</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div style="padding-bottom: 25px;">
            <div class="title">
                <span style="padding:0 5px">本一</span><a-icon type="down"></a-icon>
            </div>
            <div>
                <div class="volunteer-list-title" style="display: flex;">
                    <div style="flex: 1;">第一志愿</div>
                    <div style="flex: 1;">北京大学</div>
                    <div style="flex: 1;">10001</div>
                </div>
                <div style="display: flex;" class="volunteer-list-major">
                    <div style="width: 50%;display: flex;margin-right: 10px" class="volunteer-list-major-wrap">
                        <div style="width: 30px">01</div>
                        <div style="flex: 1">农学</div>
                        <div style="flex: 1">010101</div>
                    </div>
                    <div style="width: 50%;display: flex;margin-left: 10px;" class="volunteer-list-major-wrap">
                        <div style="width: 30px">01</div>
                        <div style="flex: 1">农学</div>
                        <div style="flex: 1">010101</div>
                    </div>
                </div>
            </div>
            <div>
                <div class="volunteer-list-title" style="display: flex;">
                    <div style="flex: 1;">第一志愿</div>
                    <div style="flex: 1;">北京大学</div>
                    <div style="flex: 1;">10001</div>
                </div>
                <div style="display: flex;" class="volunteer-list-major">
                    <div style="width: 50%;display: flex;margin-right: 10px" class="volunteer-list-major-wrap">
                        <div style="width: 30px">01</div>
                        <div style="flex: 1">农学</div>
                        <div style="flex: 1">010101</div>
                    </div>
                    <div style="width: 50%;display: flex;margin-left: 10px;" class="volunteer-list-major-wrap">
                        <div style="width: 30px">01</div>
                        <div style="flex: 1">农学</div>
                        <div style="flex: 1">010101</div>
                    </div>
                </div>
            </div>
        </div>
        <!--<van-collapse v-model="activeNames">-->
            <!--<van-collapse-item title="有赞微商城"  name="1">-->
                <!--提供多样店铺模板，快速搭建网上商城-->
            <!--</van-collapse-item>-->
            <!--<van-collapse-item title="有赞零售" name="2">-->
                <!--网店吸粉获客、会员分层营销、一机多种收款，告别经营低效和客户流失-->
            <!--</van-collapse-item>-->
            <!--<van-collapse-item title="有赞美业" name="3">-->
                <!--线上拓客，随时预约，贴心顺手的开单收银-->
            <!--</van-collapse-item>-->
        <!--</van-collapse>-->
    </div>
</template>

<script>
    export default {
        name: "myVolunteerDetail",
        data(){
            return {
                showDetail:true
            }
        },
        methods:{
            changeDownUp(){
                this.showDetail = !this.showDetail;
            }
        }
    }
</script>

<style scoped>
    .title{
        text-align: center;
        padding: 5px;
        background: #0099ff;
        color: white;
    }

    .volunteer-list-title{
        text-align: center;
        color: #333333;
        margin: 15px 0;
    }

    .volunteer-list-title>div{
        border: 1px solid #d2d2d2;
        padding: 5px 0;
        font-size: 14px;
    }

    .volunteer-list-major{
        padding: 0 15px;
        font-size: 14px;
    }

    .volunteer-list-major-wrap{
        text-align: center;
    }

    .volunteer-list-major-wrap>div{
        border: 1px solid #f2f2f2;
        padding: 5px 0;
    }
</style>