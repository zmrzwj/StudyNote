import Vue from 'vue'
import App from './myVolunteerDetail.vue'


import 'ant-design-vue/dist/antd.css';
import { Icon } from 'ant-design-vue'

Vue.use(Icon)

Vue.config.productionTip = false

new Vue({

  render: h => h(App)
}).$mount('#app')
