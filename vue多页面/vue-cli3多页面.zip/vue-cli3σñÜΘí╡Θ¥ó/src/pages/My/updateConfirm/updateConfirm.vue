<template>
    <div class="updateConfirm">
        <div style="padding: 15px;border-bottom: 1px solid #f2f2f2;">
            <span style="font-size: 18px;font-weight: normal;">阿尔法志愿VIP-确认订单</span><span style="float: right;color:#999;line-height: 27px;">X</span>
        </div>
        <div style="font-size: 16px;">
            <div class="list">
                <div class="list-name">开通服务</div>
                <div style="border: 1px solid #ff9933;padding:10px 10px;border-radius: 3px;background: rgba(255,102,0,0.15);color:#ff9933; ">
                    <img :src="vipLogo" style="width: 35px;height: 35px;float: left;"/>
                    <div style="float: left;line-height: 35px;">阿尔法志愿VIP</div>
                </div>
            </div>

            <div class="list">
                <div class="list-name">支付金额</div>
                <div style="color:#ff9933;">￥398</div>
            </div>

            <div class="list">
                <div class="list-name">支付方式</div>
                <div style="color: #666;font-size: 13px;">
                    <img :src="weixinLogo" style="width: 24px;height: 24px;float: left;"/>
                    <div style="padding-left: 5px;float: left;line-height: 24px;">微信支付</div>
                </div>
            </div>

            <div class="list">
                <div class="list-name">开通账号</div>
                <div style="font-size: 14px;color: #666666;">15208259953(手机）</div>
            </div>

            <div style="text-align: center;margin-top: 15px;">
                <a href="payIndex.html">
                    <span class="orange button">
                        立即支付
                    </span>
                </a>

            </div>

        </div>
    </div>
</template>

<script>
    export default {
        name: "updateConfirm",
        data(){
            return {
                weixinLogo:require("../../../assets/my/update/weixin-logo.png"),
                vipLogo:require("../../../assets/my/update/VIP-logo.png"),
            }
        }
    }
</script>

<style scoped>
    .list{
        display: flex;
        align-items: center;
        padding: 15px 25px;
    }

    .list-name{
        padding-right: 25px;
    }

    .orange{
        background: #ff6600;
        color: white;
    }

    .button{
        padding: 8px 50px;
        border-radius: 5px;
        display: inline-block;
    }
</style>