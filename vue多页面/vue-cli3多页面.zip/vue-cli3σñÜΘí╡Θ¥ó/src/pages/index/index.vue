<template>
    <div class="index">
        <div class="child">
            <div :style="{backgroundImage:'url(' + img + ')'}" class="headImage" style="text-align: center;display: flex;align-items: center;flex-direction: column;justify-content: center;">
                <div style="background: rgba(255,255,255,0.8);display: inline-block;padding: 10px;">
                    <div style="font-size: 18px;color: #333333;">填志愿就找<span style="color:#2553ff;">阿尔法</span></div>
                    <div style="font-size: 12px;">精准、权威、智能</div>
                </div>
                <div style="padding: 15px 0;">
                    <a href="expertIndex.html">
                        <span style="background:#ff0033;color: white;border-radius: 50px;padding: 8px 20px;display: inline-block;">
                        专家一对一帮填
                        </span>
                    </a>

                </div>
            </div>
            <div style="text-align: center;padding: 5px 15px;background: white;">
                <img :src="soundIcon" style="width: 20px;height: 20px;float: left;"/>
                <span style="color: #333333;">xxx购卡</span>
                <img :src="fingerIcon" style="width: 18px;height: 22px;float: right;"/>
            </div>
        </div>
        <div class="child">
            <div style="padding: 15px 0 0 0;height: 100%;">
                <div style="padding:10px 15px;background: white;height: 100%;">
                    <div class="title">
                        I Can
                    </div>

                    <div  class="iCan">
                        <div style="height: 100%;display: flex;">
                            <div style="height: 100%;padding: 10px 0 0 0;flex: 1;">
                                <div style="height: 20px;">赵丽颖</div>
                                <div class="myScore" style="position: relative;">
                                    <div id="scoreBar" style="width: 100%;height: 100%;"></div>
                                </div>
                                <div style="height:36px;">
                                    <div>
                                        在全省55万考生中
                                    </div>
                                    <div>
                                        排名第30000位
                                    </div>
                                </div>
                            </div>

                            <div style="height: 100%;padding: 10px 0 0 0;flex: 2;">
                                <div style="height: 20px">
                                    我能上等学校/所
                                </div>
                                <div style="height: calc( 100% - 40px );width: 100%;display: flex;flex-direction: column;">
                                    <div   style="width: 100%;position: relative;display: flex;padding: 0 0 0 15px;flex: 1;align-items: center;" v-for="item in iCans">
                                        <div  style="width: 30px;">{{item.name}}</div>
                                        <div class="bar" style="flex: 1;border-radius: 10px;" >
                                            <div style="height: 100%;background:#0183ff;border-radius: 10px;" :style="{width:item.number+'px'}"></div>
                                        </div>
                                        <div class="right" style="width: 20px;">{{item.number}}</div>
                                    </div>
                                </div>
                                <div style="line-height: 20px;">
                                    <div class="left">
                                        同分考生:1234
                                    </div>
                                    <div class="left">
                                        我的位次:300000位
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

            </div>

        </div>
        <div class="child">
            <div style="height: 100%;padding-top: 15px;">
                <div style="padding: 15px;background: white;height: 100%;">
                    <div class="title">高考服务一键导航</div>

                    <div style="text-align: center;padding: 15px 0;font-size: 14px;font-weight: bold;line-height: 28px;display: flex;">
                        <div style="flex: 1;">
                            <a href="./searchIndex.html">
                                <div class="wrap-img">
                                    <img :src="searchImg"/>
                                </div>
                                <div>查一查</div>
                            </a>
                        </div>
                        <div style="flex: 1;">
                            <a href="./compareIndex.html">
                                <div class="wrap-img">
                                    <img :src="compareImg"/>
                                </div>
                                <div>比一比</div>
                            </a>
                        </div>
                        <div style="flex: 1;">
                            <a href="#">
                                <div class="wrap-img">
                                    <img :src="fillImg"/>
                                </div>
                                <div>填一填</div>
                            </a>
                        </div>
                        <div style="flex: 1;">
                            <a href="./myIndex.html">
                                <div class="wrap-img">
                                    <img :src="myImg"/>
                                </div>
                                <div>我的</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>



        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts'
    import "echarts/lib/chart/pie"
    import "echarts/lib/component/title"

    export default {
        name: "index",
        data(){
            return {
                img:require("../../assets/index/head-img.png"),
                fillImg:require("../../assets/index/fill.png"),
                myImg:require("../../assets/index/my.png"),
                searchImg:require("../../assets/index/search.png"),
                compareImg:require("../../assets/index/compare.png"),

                fingerIcon:require("../../assets/index/fingerIcon.png"),
                soundIcon:require("../../assets/index/soundIcon.png"),

                iCans:[
                    {
                        name:"热门",
                        number:80,
                    },
                    {
                        name:"本一",
                        number:60,
                    },
                    {
                        name:"本二",
                        number:50,
                    },
                    {
                        name:"专科",
                        number:90,
                    }
                ]
            }

        },
        mounted(){
            this.scoreBar(580);
        },
        methods:{
            scoreBar(score){
                //scoreBar
                var echart = echarts.init(document.getElementById("scoreBar"));

                var option = {
                    title: {
                        text: '580分\n您的分数',
                        x: 'center',
                        y: 'center',
                        textStyle: {
                            fontWeight: 'normal',
                            color: '#0099ff',
                            fontSize: '14'
                        }
                    },
                    color: ['rgba(176, 212, 251, 1)'],
                    series: [{
                        name: 'Line 1',
                        type: 'pie',
                        clockWise: true,
                        radius: ['80%', '100%'],
                        itemStyle: {
                            normal: {
                                label: {
                                    show: false
                                },
                                labelLine: {
                                    show: false
                                }
                            }
                        },
                        hoverAnimation: false,
                        data: [{
                            value: parseInt(score*100/750),
                            name: '01',
                            itemStyle: {
                                normal: {
                                    color: { // 完成的圆环的颜色
                                        colorStops: [{
                                            offset: 0,
                                            color: '#ffcc00' // 0% 处的颜色
                                        }, {
                                            offset: 1,
                                            color: '#ffcc00' // 100% 处的颜色
                                        }]
                                    },
                                    label: {
                                        show: false
                                    },
                                    labelLine: {
                                        show: false
                                    }
                                }
                            }
                        }, {
                            name: '02',
                            value: 100 - parseInt(score*100/750),
                            itemStyle: {
                                normal: {
                                    color: { // 完成的圆环的颜色
                                        colorStops: [{
                                            offset: 0,
                                            color: '#0099ff' // 0% 处的颜色
                                        }, {
                                            offset: 1,
                                            color: '#0099ff' // 100% 处的颜色
                                        }]
                                    },
                                    label: {
                                        show: false
                                    },
                                    labelLine: {
                                        show: false
                                    }
                                }
                            }
                        }]
                    }]
                }

                echart.setOption(option);
            }
        }
    }
</script>

<style scoped>
    .index{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        display: flex;
        flex-direction: column;
        overflow-x: hidden;
    }

    .child{
        flex: 1;
    }

    .title{
        border-left: 2px solid #0183ff;
        padding-left: 5px;
        line-height: 21px;
        font-size: 20px;
        font-weight: bold;
    }

    .headImage{
        height: calc( 100% - 31px);
        background-size: 100% 100%;
    }

    .wrap-img img{
        width: 50px;
        height: 50px;
    }

    .iCan{
        font-size: 10px;
        font-weight: normal;
        text-align: center;
        height: calc( 100% - 21px );
        position: relative;
    }

    .myScore{
        height: calc( 100% - 56px );
        padding: 5px;
    }

    .out-bar{
        width: 100%;
        height: 100%;
        border: 3px solid #0099ff;
        border-radius: 50%;
        position: relative;
    }
    .inner-bar{
        width: 100%;
        height: 100%;
        border: 3px solid #ffcc00;
        border-radius: 50%;
    }
    .bar{
        height: 18px;
        background: #f2f2f2;
    }


    .left{
        float: left;
        width: 50%;
    }
    .right{
        float: right;
    }
    .clear:after{
        content: " ";
        display: block;
        clear: both;
    }

    a{
        text-decoration: none;
        color: #0099ff;
    }
</style>