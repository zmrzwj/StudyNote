<template>
    <div class="firstLogin">
        <head-logo></head-logo>
        <div style="padding: 25px 0;">
            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-select style="width: 100%;" placeholder="请选择您所在的地区" size="large">
                    <a-select-option v-for="item in areas" :value="item">{{item}}</a-select-option>
                </a-select>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-select style="width: 100%;" placeholder="请选择您的高中" size="large">
                    <a-select-option v-for="item in highSchools" :value="item">{{item}}</a-select-option>
                </a-select>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;" >
                <a-select style="width: 60%;" placeholder="请选择文理科" size="large">
                    <a-select-option v-for="item in wenli" :value="item">{{item}}</a-select-option>
                </a-select>
                <a-select style="width: 38%;float: right;" placeholder="性别" size="large">
                    <a-select-option v-for="item in sex" :value="item">{{item}}</a-select-option>
                </a-select>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-select style="width: 100%;" placeholder="请选择语种" size="large" language>
                    <a-select-option v-for="item in languages" :value="item">{{item}}</a-select-option>
                </a-select>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入您的高考分数" v-model="score"/>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入您的姓名" v-model="name"/>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <div style="padding: 8px;background:#0099ff;color: white;font-size: 16px;border-radius: 3px;" @click="ok()">
                    确认
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import HeadLogo from "../../components/HeadLogo.vue"
    export default {
        name: "firstLogin",
        components:{
            HeadLogo
        },
        data(){
            return {
                areas:['Home'],
                highSchools:['Home'],
                wenli:['Home'],
                sex:['男','女'],
                languages:['Home'],

                score:"",
                name:"",

            }
        },
        methods:{
            ok(){

            }
        }

    }
</script>

<style scoped>

    .firstLogin{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        padding: 30px 0;

    }

    .justify-content_flex-justify{
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
    }


</style>