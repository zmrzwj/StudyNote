<template>
    <div class="expertAppointmentSuccess" style="text-align: center;">
        <div style="padding:70px 0 25px 0;">
            <img :src="paySuccess" style="width: 150px;height: 120px;"/>
        </div>
        <div style="padding: 10px 0;">
            <span style="font-size: 21px;color: #555;">预约成功</span>
        </div>
        <div style="padding:0 35px 15px 35px;font-size: 16px;">
            <span>您已预约成功，请注意接收并保留短信，我们将会尽快与您联系，请留意接听电话。您也可以拨打电话13438876191进行咨询。</span>
        </div>

        <div style="padding: 15px;text-align: center;font-size: 18px;">
            <a href="fillIndex.html">
                <span style="color:white;background:#00cc00;padding: 10px 35px;border-radius: 5px;">返回填一填</span>
            </a>
        </div>

        <div>
            <span>{{time}}秒后自动跳转</span>
        </div>
    </div>
</template>

<script>
    export default {
        name: "expertAppointmentSuccess",
        data(){
            return {
                paySuccess:require("../../../assets/fill/expert/success.png"),
                time:3
            }
        },
        mounted(){
            var _this = this;
            window.setInterval(function(){
                _this.time = _this.time - 1;
                if(_this.time === 0){
                    window.location.href="fillIndex.html";
                }
            },1000)
        }
    }
</script>

<style scoped>

</style>