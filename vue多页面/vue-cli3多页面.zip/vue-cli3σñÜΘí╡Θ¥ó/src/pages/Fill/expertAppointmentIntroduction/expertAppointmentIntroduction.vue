<template>
    <div class="expertAppointment">
        <div style="height: 150px;width: 100%;background-size: cover;background-position: center;"
             :style="{backgroundImage:'url('+head+')'}"
        >
        </div>

        <div style="text-align: center;padding: 15px 0;font-size: 16px;">
            <p style="color:#0099ff;">专家一对一志愿服务</p>
        </div>

        <div style="padding:0 15px;">
            <div style="box-shadow: 0 0 5px #aaaaaa;padding: 15px;background: white;margin-bottom: 5px;">
                <div style="display: flex;color:#0099ff;padding: 15px 0;text-align: center;">
                    <div style="flex: 1;">全价：<span style="color:#ff6600;">8800元</span></div>
                    <div style="flex: 1;">定金：<span style="color:#ff6600;">500元</span></div>
                </div>
                <div style="font-size: 12px;text-align: center;padding:5px 0 15px 0;">
                    <span style="color:#0099ff;">6月8日前</span>交500元<span style="color:#0099ff;">送价值398元的VIP卡</span>，凭短信进行抵扣
                </div>
            </div>
        </div>

        <div style="background: #f2f2f2;">
            <div style="padding: 15px;">
                <div style="color:#0099ff;text-align: center;padding: 5px;">
                    <p>服务介绍</p>
                </div>

                <div style="font-size: 13px;line-height: 20px;">
                    专家对一服务，分三阶段为考生提供职业规划、考前预填、真实填报，逐步深入了解学生的实际情况，科学规划出最适合学生的志愿填报结果，助学生金榜题名！
                </div>
            </div>

            <div>
                <div style="color:#0099ff;text-align: center;padding: 5px;">
                    <p>服务流程</p>
                </div>

                <div style="display: flex;text-align: center;color:#0099ff;font-size: 14px;">
                    <div style="flex: 1;">
                        <div>
                            <img style="width: 50px;height: 50px;" :src="step1"/>
                        </div>
                        <div>职业规划</div>
                    </div>
                    <div style="flex: 1;">
                        <div>
                            <img style="width: 50px;height: 50px;" :src="step2"/>
                        </div>
                        <div>考前预填</div>
                    </div>
                    <div style="flex: 1;">
                        <div>
                            <img style="width: 50px;height: 50px;" :src="step3"/>
                        </div>
                        <div>真实填报</div>
                    </div>
                </div>
            </div>


            <div style="padding: 15px;">
                <div style="padding: 10px 0;">
                    <div style="color:#0099ff;font-size: 14px;">1、职业规划</div>
                    <div style="font-size: 13px;line-height: 20px;">专家同考生进行第一次线下一 -对一接触，通过对考生的兴趣偏好、职业倾向综合测评,为考生初步制定个性化高考填报方案 </div>
                </div>

                <div style="padding: 10px 0;">
                    <div style="color:#0099ff;font-size: 14px;">2、考前预填</div>
                    <div style="font-size: 13px;line-height: 20px;">
                        专家同考生进行第二次线下一对一接触，考前根据学生成。专家同考生进行第二次线下一对一接触，考前根据学生成。专家同考生进行第二次线下一对一接触，考前根据学生成。
                    </div>
                </div>

                <div style="padding: 10px 0;">
                    <div style="color:#0099ff;font-size: 14px;">3、真实填报</div>
                    <div style="font-size: 13px;line-height: 20px;">
                        专家同考生进行第二次线下一对一接触，考前根据学生成。专家同考生进行第二次线下一对一接触，考前根据学生成。专家同考生进行第二次线下一对一接触，考前根据学生成。
                    </div>
                </div>
            </div>
        </div>

        <div style="text-align: center;padding: 25px;">
            <span style="padding: 10px 50px;background:#0099ff;border-radius: 50px;color: white;">立即预约</span>
        </div>


    </div>
</template>

<script>
    export default {
        name: "expertAppointment",
        data(){
            return {
                head:require("../../../assets/fill/expert/serviceIntroduction.png"),
                step1:require("../../../assets/fill/expert/step1.png"),
                step2:require("../../../assets/fill/expert/step2.png"),
                step3:require("../../../assets/fill/expert/step3.png"),
            }
        }
    }
</script>

<style scoped>

    .expertAppointment{
        background: #f2f2f2;
        width: 100%;
    }
</style>