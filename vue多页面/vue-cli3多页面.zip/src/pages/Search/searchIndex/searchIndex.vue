<template>
    <div class="searchIndex">
        <div>

        </div>

        <div>

        </div>

        <div class="searchNav">
            <div class="title">查一查一键导航</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>
    .searchIndex{
        width: 100%;
        height: 100%;
    }

    .searchNav{
        padding: 15px;
    }
    .searchNav .title{
        border-left: 2px solid #0099ff;
        padding-left: 5px;
        font-size: 16px;
    }
</style>