<template>
    <div class="VIPBind">
        <head-logo></head-logo>

        <div style="padding: 25px 0;">
            <div style="width: 250px;padding: 5px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入卡号" v-model="username"/>
            </div>

            <div style="width: 250px;padding:10px 0;text-align: center;margin: auto;">
                <a-row :gutter="15">
                    <a-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
                        <div style="padding: 8px;background:#0099ff;color: white;font-size: 16px;border-radius: 3px;" @click="bind()">
                            绑定
                        </div>
                    </a-col>

                    <a-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
                        <div style="padding: 8px;background: white;color: #666;font-size: 16px;border-radius: 3px;" @click="skip()">
                            跳过
                        </div>
                    </a-col>
                </a-row>



            </div>
        </div>
    </div>
</template>

<script>
    import HeadLogo from "../../components/HeadLogo.vue"
    import ARow from "ant-design-vue/es/grid/Row";
    import ACol from "ant-design-vue/es/grid/Col";

    export default {
        name: "VIPBind",
        components:{
            ACol,
            ARow,
            HeadLogo
        },
        data(){
            return {

            }
        },
        methods:{
            bind(){

            },
            skip(){

            }
        }

    }
</script>

<style scoped>
    .VIPBind{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        padding: 30px 0;
    }


</style>