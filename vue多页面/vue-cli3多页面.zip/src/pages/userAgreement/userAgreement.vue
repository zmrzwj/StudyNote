<template>
    <div class="userAgreement">
        <h2 style="text-align: center;">用户协议</h2>
        <div style="text-indent: 2em;">
            xxxxxxxxxxxxxxxxxxxxxx
        </div>
    </div>
</template>

<script>
    export default {
        name: "userAgreement",
        data(){
            return {

            }
        },

    }
</script>

<style scoped>
    .userAgreement{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        padding: 15px;
    }


</style>