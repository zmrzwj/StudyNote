<template>
    <div class="login">
        <head-logo></head-logo>

        <div style="padding: 25px 0;">
            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入手机号" v-model="username"/>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入登录密码" v-model="password"/>
            </div>

            <div style="padding: 10px 0;font-size: 16px;">
                <div style="width: 250px;padding: 8px 0;text-align: center;margin: auto;background:#0183ff;color: white;">登录</div>
                <div class="clear" style="width: 250px;color:#0183ff;margin: auto;padding: 5px 0;">
                    <span class="left">
                        <a href="./forgetPassword.html">忘记密码？</a>
                    </span>
                    <span class="right">注册新用户</span>
                </div>
            </div>


        </div>

    </div>
</template>

<script>
    import HeadLogo from "../../components/HeadLogo.vue"
    export default {
        name: "login",
        components:{
            HeadLogo
        },
        data(){
            return {
                logo:require('../../assets/login/login-logo.png'),

                username:"",
                password:""
            }
        },

    }
</script>

<style scoped>

    .login{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        padding: 30px 0;

    }

    .justify-content_flex-justify{
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
    }
</style>