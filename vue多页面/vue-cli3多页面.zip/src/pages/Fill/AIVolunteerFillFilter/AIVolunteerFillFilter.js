import Vue from 'vue'
import App from './AIVolunteerFillFilter.vue'
import '../../../public/css/public.css'


import 'vant/lib/index.css';

import { Icon } from 'vant';
Vue.use(Icon);

Vue.config.productionTip = false

new Vue({

  render: h => h(App)
}).$mount('#app')
