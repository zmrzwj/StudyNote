<template>
    <div>
        <BackHead title="偏好设置"></BackHead>
        <div style="padding: 0 10px;margin-bottom: 15px;">
            <div class="title">选择意向地区</div>
            <div style="text-align: center;" class="clear">
                <div v-for="item in area" class="wrap-button">
                    <div class="button" :class="{'active':selectArea == item}" @click="areaClick(item)">
                        {{item}}
                    </div>
                </div>
            </div>
        </div>
        <div style="padding: 0 10px;margin-bottom: 15px;">
            <div class="title">选择学校类型</div>
            <div style="text-align: center;" class="clear">
                <div v-for="item in schoolType" class="wrap-button">
                    <div class="button" :class="{'active':selectSchoolType == item}" @click="schoolTypeClick(item)">
                        {{item}}
                    </div>
                </div>
            </div>
        </div>
        <div style="padding: 0 10px;margin-bottom: 15px;">
            <div class="title">选择学校批次</div>
            <div style="text-align: center;" class="clear">
                <div v-for="item in batch"  class="wrap-button">
                    <div class="button" :class="{'active':selectBatch == item}" @click="batchClick(item)">
                        {{item}}
                    </div>
                </div>
            </div>
        </div>
        <div style="padding: 0 10px;margin-bottom: 15px;">
            <div class="title">选择院校类型</div>
            <div style="text-align: center;" class="clear">
                <div v-for="item in academyType"  class="wrap-button">
                    <div class="button" :class="{'active':selectAcademyType == item}" @click="academyTypeClick(item)">
                        {{item}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import BackHead from "../../../components/BackHead.vue"

    export default {
        name: "AIVolunteerFillFilter",
        components:{
            BackHead
        },
        data(){
            return {
                area:[
                    "不限",
                    "北京",
                    "福建",
                    "安徽",
                    "甘肃",
                    "广东",
                    "广西",
                    "贵州",
                    "海南",
                    "河北",
                    "河南",
                    "黑龙江",
                    "湖北",
                    "湖南",
                    "吉林",
                    "江苏",
                    "江西",
                    "辽宁",
                    "内蒙古",
                    "宁夏",
                    "青海",
                    "山东",
                    "山西",
                    "陕西",
                    "上海",
                    "四川",
                    "天津",
                    "云南",
                    "浙江",
                    "重庆",
                    "西藏",
                    "新疆",
                ],
                schoolType:[
                    "普通公办院校","985","211","双一流"
                ],
                batch:[
                    "提前批","国家专项","地方专项","一本","二本","专科"
                ],
                academyType:[
                    "综合","理工","财经","农林","医药","师范","民族","艺术","政法","体育","军事","语言"
                ],

                selectArea:"不限",
                selectSchoolType:"普通公办院校",
                selectBatch:"提前批",
                selectAcademyType:"综合",
            }
        },
        methods:{
            areaClick(item){
                this.selectArea = item;
            },
            schoolTypeClick(item){
                this.selectSchoolType = item;
            },
            batchClick(item){
                this.selectBatch = item;
            },
            academyTypeClick(item){
                this.selectAcademyType = item;
            },
        }
    }
</script>

<style scoped>
    .title{
        font-size: 16px;
        padding:5px 3px;
    }

    .wrap-button{
        padding: 3px;
        width: 25%;
        float: left;
    }

    .button{
        border: 1px solid #e2e2e2;
        padding: 5px 0;
        border-radius: 3px;
        font-size: 12px;
        box-sizing: border-box;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space:nowrap
    }

    .active{
        background: #0099ff;
        color: white;
        border: 1px solid transparent;
    }
</style>