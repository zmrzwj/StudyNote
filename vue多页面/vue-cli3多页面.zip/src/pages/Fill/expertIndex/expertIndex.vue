<template>
    <div class="expertIndex">
        <div style="padding: 35px;">
            <div style="display: flex;justify-content: center;text-align: center;font-size: 16px;">
                <div style="width:160px;background:#0099ff;padding: 5px;color:white;border-top-left-radius: 20px;border-bottom-left-radius: 20px;">专家列表</div>
                <a href="expertAppointmentIntroduction.html" style="text-decoration: none;color: #0099ff;">
                    <div style="width:160px;padding: 5px;border: 1px solid #0099ff;border-top-right-radius: 20px;border-bottom-right-radius: 20px;">一对一服务介绍</div>
                </a>
            </div>
        </div>

        <div>
            <div style="background: white;position: relative;height: auto;margin-bottom: 35px;">
                <div style="background:#ff6666;color: white;border-radius: 50%;position: absolute;padding: 10px;font-size: 10px;right: 5px;top:-15px;">
                    <div>已辅导</div>
                    <div>356人</div>
                </div>
                <div style="display: flex;align-items: center;">
                    <div style="padding: 15px;">
                        <img :src="teacher" style="width: 100px;height: 100px;"/>
                    </div>
                    <div style="padding:25px 15px 25px 0;line-height: 23px;font-size: 13px;">
                        <div style="padding: 2px 0;">
                            <span style="color:#ff6666;font-size: 16px;padding-right: 5px;">刘老师</span>
                            <span>教育部知名专家 </span>
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">专长：</span>
                            <span>理工类 经济类</span>
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">背景介绍：</span>电子科技大学数据博士，电子科技大学数据博士，电子科技大学数据博士，电子科技大学数据博士，电子科技电子科技大学数据博士
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">服务类别：</span>职业规划 志愿填报 拷贝 2
                        </div>
                    </div>
                </div>
            </div>

            <div style="background: white;position: relative;height: auto;margin-bottom: 35px;">
                <div style="background:#ff6666;color: white;border-radius: 50%;position: absolute;padding: 10px;font-size: 10px;right: 5px;top:-15px;">
                    <div>已辅导</div>
                    <div>356人</div>
                </div>
                <div style="display: flex;align-items: center;">
                    <div style="padding: 15px;">
                        <img :src="teacher" style="width: 100px;height: 100px;"/>
                    </div>
                    <div style="padding:25px 15px 25px 0;line-height: 23px;font-size: 13px;">
                        <div style="padding: 2px 0;">
                            <span style="color:#ff6666;font-size: 16px;padding-right: 5px;">刘老师</span>
                            <span>教育部知名专家 </span>
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">专长：</span>
                            <span>理工类 经济类</span>
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">背景介绍：</span>电子科技大学数据博士，电子科技大学数据博士，电子科技大学数据博士，电子科技大学数据博士，电子科技电子科技大学数据博士
                        </div>
                        <div style="padding: 2px 0;">
                            <span style="color:#0099ff;">服务类别：</span>职业规划 志愿填报 拷贝 2
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div style="text-align: center;">
            <a href="./expertAppointment.html">
                <span style="background:#0099ff;color: white;padding: 10px 35px;display: inline-block;border-radius: 50px;">咨询预定</span>
            </a>
        </div>
    </div>
</template>

<script>
    export default {
        name: "expertIndex",
        data(){
            return {
                teacher:require("../../../assets/fill/expert/teacher.png")
            }
        }
    }
</script>

<style scoped>

    .expertIndex{
        background: #f2f2f2;
        color: #666;
        height: 100%;
    }
</style>