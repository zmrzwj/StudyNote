<template>
    <div class="expertAppointment">
        <div class="wrap-input">
            <input class="myInput" type="text" placeholder="请输入姓名"/>
        </div>

        <div class="wrap-input">
            <input class="myInput" type="text" placeholder="请输入手机号"/>
        </div>

        <div class="wrap-input">
            <input class="myInput" type="text" placeholder="请输入所属地区"/>
        </div>

        <div class="wrap-input">
            <input class="myInput" type="text" placeholder="文科" />
        </div>

        <div style="text-align: center;padding: 15px 0;">
            <div style="padding: 5px 0;">
                <img :src="moneyImg" style="width: 80px;height: 80px;"/>
            </div>
            <div style="color:#999;">交定金<span style="color:#cc3333;">100可抵600</span>，凭短信进行抵扣!!</div>
        </div>

        <div style="text-align: center;padding: 25px 0;">
            <span style="background:#0099ff;color: white;padding: 10px 45px;border-radius: 50px;font-size: 18px;">
                立即支付
            </span>
        </div>
    </div>
</template>

<script>
    export default {
        name: "expertAppointment",
        data(){
            return {
                moneyImg:require("../../../assets/fill/expert/money.png")
            }
        }
    }
</script>

<style scoped>
    .wrap-input{
        text-align: center;
        padding: 15px 0;
    }
    .myInput{
        border: 1px solid #c2c2c2;
        padding: 10px;
        font-size: 18px;
        border-radius: 25px;
        width: 70%;
        text-align: center;
    }

    .myInput{
        outline: none;
    }

    .myInput:focus{
        color: #0099ff;
        border: 1px solid #0099ff;
        transition:all 0.3s ease;
    }
</style>