import Vue from 'vue'
import App from './AIVolunteerFillResult.vue'

import 'ant-design-vue/dist/antd.css';
import { Icon } from 'ant-design-vue'

Vue.use(Icon)

Vue.config.productionTip = false

new Vue({

  render: h => h(App)
}).$mount('#app')
