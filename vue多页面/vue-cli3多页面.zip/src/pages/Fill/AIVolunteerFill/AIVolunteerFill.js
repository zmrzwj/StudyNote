import Vue from 'vue'
import App from './AIVolunteerFill.vue'
import '../../../public/css/public.css'


import 'vant/lib/index.css';

import { Loading } from 'vant';

Vue.use(Loading);

Vue.config.productionTip = false

new Vue({

  render: h => h(App)
}).$mount('#app')
