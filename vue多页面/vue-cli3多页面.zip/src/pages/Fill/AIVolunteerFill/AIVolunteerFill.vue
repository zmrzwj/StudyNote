<template>
    <div>
        <div style="background-size: 100% 100%;display: flex;height: 260px;color: white;text-align: center;font-size: 16px;font-weight: lighter;padding: 15px 0;"
                :style="{backgroundImage:'url('+headBg+')'}">
            <div style="flex: 1;">
                <img :src="positionIcon" style="width: 20px;height: 24px;"/><span style="padding: 0 5px;">{{positionText}}</span>
            </div>
            <div style="flex: 1;">
                <img :src="avatarIcon" style="width: 20px;height: 24px;"/><span style="padding: 0 5px;">{{avatarText}}</span>
            </div>
            <div style="flex: 1;">
                <img :src="scoreIcon" style="width: 20px;height: 24px;"/><span style="padding: 0 5px;">{{score}}</span>
            </div>
        </div>

        <div>
            <div style="text-align:center;">
                <img :src="rocketIcon" style="width: 75px;height: 80px;"/>
            </div>
            <div style="text-align: center;padding: 25px 0;">
                <span style="padding: 10px 25px;background:#0099ff;color: white;border-radius:50px;">一键生成志愿</span>
            </div>
        </div>

        <div :class="{'height100':isUp}" class="actionsheet">
            <div style="text-align: center;">
                <div @click="upClick" style="padding: 5px 0;">
                    <img :src="upIcon" style="width: 35px;height: 35px;" :class="{'down':isUp}" />
                </div>
                <div style="font-size: 16px;">
                    往上滑设置
                </div>
            </div>
            <div style="font-size: 16px;">
                <div class="list">
                    <span>学校类型</span><span style="float: right;">不限</span>
                </div>
                <div class="list">
                    <span>学校批次</span><span style="float: right;">不限</span>
                </div>
                <div class="list">
                    <span>专业类别</span><span style="float: right;">不限</span>
                </div>
                <div class="list">
                    <span>学校地区</span><span style="float: right;">不限</span>
                </div>
            </div>
        </div>

        <div v-show="isLoading" style="position: fixed;width: 100%;height: 100%;top: 0;bottom: 0;display: flex;justify-content: center;align-items: center;">
            <span style="padding: 15px;background: rgba(5,5,5,0.6);border-radius: 10px;">
                <van-loading type="spinner" size="40px" color="white"/>
            </span>
        </div>

    </div>
</template>

<script>
    export default {
        name: "AIVolunteerFill",
        data(){
            return {
                avatarIcon:require("../../../assets/fill/AI/avatar.png"),
                positionIcon:require("../../../assets/fill/AI/position.png"),
                rocketIcon:require("../../../assets/fill/AI/rocket.png"),
                scoreIcon:require("../../../assets/fill/AI/score.png"),
                upIcon:require("../../../assets/fill/AI/up.png"),
                headBg:require("../../../assets/fill/AI/head-bg.png"),

                positionText:"四川",
                avatarText:"赵丽颖",
                score:"580",

                isUp:false,
                isLoading:false,
            }
        },
        methods:{
            upClick(){
                this.isUp = !this.isUp;
            }
        }
    }
</script>

<style scoped>
    .list{
        padding:5px 15px;
    }

    .down{
        transform: rotateX(180deg);
    }

    .actionsheet{
        box-shadow: 0 0 5px #c2c2c2;
        position: fixed;
        bottom: 0;
        width: 100%;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
        padding: 25px 0;
        background: white;
    }

    .height100{
        height: 100%;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
    }
</style>