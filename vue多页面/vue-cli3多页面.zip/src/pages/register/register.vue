<template>
    <div class="register">
        <head-logo></head-logo>

        <div style="padding: 25px 0;">
            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入手机号" v-model="username"/>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: left;margin: auto;">
                <a-input size="large" placeholder="验证码" v-model="code" style="width: 160px;"/>
                <span class="button" style="float: right;">获取验证码</span>
            </div>

            <div style="width: 250px;padding: 10px 0;text-align: center;margin: auto;">
                <a-input size="large" placeholder="请输入密码" v-model="username"/>
            </div>

            <div style="width: 250px;padding:0;text-align: center;margin: auto;">
                <a-radio>
                    注册即同意<a href="./userAgreement.html">《用户协议》</a>
                </a-radio>
            </div>

            <div style="width: 250px;padding: 20px 0;text-align: center;margin: auto;">
                <div style="padding: 8px;background:#0099ff;color: white;font-size: 16px;border-radius: 3px;" @click="ok()">
                    确认
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import HeadLogo from "../../components/HeadLogo.vue"
    export default {
        name: "register",
        components:{
            HeadLogo
        },
        data(){
            return {

            }
        },
        methods:{
            ok(){

            }
        }
    }
</script>

<style scoped>
    .register{
        width: 100%;
        height: 100%;
        background: #f2f2f2;
        padding: 30px 0;
    }

    .button{
        padding:0 7px;
        background: #0183ff;
        color: white;
        border-radius: 5px;
        line-height: 40px;
        font-size: 14px;
    }


</style>