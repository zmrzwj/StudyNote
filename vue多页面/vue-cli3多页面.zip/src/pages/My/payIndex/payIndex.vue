<template>
    <div class="payIndex">
        <div style="text-align: center;padding: 25px">
            <div style="font-size: 18px;">VIP卡</div>
            <div style="font-size: 48px;padding: 5px;font-weight: bold;">￥300.00</div>
        </div>
        <div class="clear info">
            <div style="float: left;">收款方</div>
            <div style="float: right;">阿尔法志愿</div>
        </div>

        <div style="padding: 25px;">
            <div style="padding: 15px;font-size: 20px;background:#00cc66;color: white;border-radius: 5px;text-align: center;">立即支付</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "payIndex",
        data(){
            return {
                gou:require("../../../assets/my/myPermission/gou.png")
            }
        }
    }
</script>

<style scoped>
    .payIndex{
        background: #f2f2f2;
        width: 100%;
        height: 100%;
    }

    .info{
        background: white;
        padding: 15px;
        font-size: 20px;
        color: #333;
    }

    .clear:after{
        content: " ";
        display: block;
        clear: both;
    }
</style>