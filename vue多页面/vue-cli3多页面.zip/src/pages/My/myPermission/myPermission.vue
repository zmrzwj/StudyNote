<template>
    <div class="myPermission">
        <div class="table">
            <table cellpadding="2" cellspacing="1">
                <thead>
                <tr>
                    <th>功能模块</th>
                    <th>功能名称</th>
                    <th>我的权限</th>
                    <th>普通卡</th>
                    <th>VIP卡</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th rowspan="8">查一查</th>
                    <th>查学校</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>查专业</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>查招生计划</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>查成绩</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>比学校</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>比专业</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>我能上的学校</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>我能上的专业</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>

                <!--<tr class="chayichabottom">-->
                    <!--<th></th>-->
                    <!--<th>查录取</th>-->
                    <!--<th class="iconfont">&#xe647;</th>-->
                    <!--<th class="iconfont">&#xe647;</th>-->
                <!--</tr>-->

                <tr>
                    <th rowspan="2">填一填</th>
                    <th>人工智能填志愿</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr class="tianyitianbottom">
                    <th>专家一对一填志愿</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>


                <tr>
                    <th rowspan="4">看一看</th>
                    <th>学科辅导</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>血涯规划</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>学校方法</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                <tr>
                    <th>心理咨询</th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                    <th>
                        <img :src="gou" class="img-gou"/>
                    </th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        name: "myPermission",
        data(){
            return {
                gou:require("../../../assets/my/myPermission/gou.png")
            }
        }
    }
</script>

<style scoped>
    .table{
        width: 100%;
    }

    .table table{
        width: 100%;
        text-align: center;
    }

    .table table thead th{
        border: 1px solid #f2f2f2;
        line-height: 28px;
    }

    .table table tbody tr th{
        border: 1px solid #f2f2f2;
        font-weight: lighter;
        line-height: 28px;
    }

    .img-gou{
        width: 13px;
        height: 13px;
    }
</style>