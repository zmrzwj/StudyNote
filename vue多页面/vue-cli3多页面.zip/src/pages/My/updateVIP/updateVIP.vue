<template>
    <div class="updateVIP">
        <div style="padding: 15px;">
            <img :src="card" style="width: 100%;"/>
        </div>
        <div>
            <h1>
                阿尔法志愿VIP卡
            </h1>
        </div>
        <div>
            <span style="font-size: 26px;">价格：</span><span style="color: #ff6600;font-size: 36px;font-weight:normal;">￥398</span>
        </div>

        <div style="margin: 25px 0;">
            <a href="updateConfirm.html">
                <span style="font-size: 22px;padding:10px 40px;background: #0099ff;color: white;border-radius: 3px;">
                    立即升级
                </span>
            </a>

        </div>
        <div style="text-align: center;color: #999;">
            <div>·适用于普通类文理科考生（不含艺术体育类）  </div>
            <div>·开通后电脑端和手机端通用</div>
            <div>
                ·有效期至2019年6月30日
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "updateVIP",
        data(){
            return {
                card:require("../../../assets/my/update/card.png")
            }
        }
    }
</script>

<style scoped>
    .updateVIP{
        text-align: center;
    }
</style>