<template>
    <div class="myVolunteerList">
        <div style="height: 15px;background: #f2f2f2;"></div>
        <a href="./myVolunteerDetail.html">
            <div style="display: flex;align-items: center;padding: 25px 15px;color: #666666;">
                <div style="width: 80px;text-align: center;position: relative;">
                    <img :src="chong" style="position: absolute;width: 20px;height: 20px;left: 0;" >
                    <img :src="schoolLogo" style="width: 60px;height: 60px;"/>
                </div>
                <div style="flex: 1;">
                    <div>
                        <sapn style="font-size: 18px;color: #333;">志愿表记录1</sapn>
                        <sapn style="padding: 0 10px;">不限地区</sapn>
                        <sapn>不限类型</sapn>
                    </div>
                    <div>
                        <span>2018-07-23</span>
                        <span style="padding: 10px;">17:55:09</span>
                    </div>
                </div>
                <div>
                    <a-icon type="right" class="icon"></a-icon>
                </div>
            </div>
        </a>

        <div style="display: flex;align-items: center;padding: 25px 15px;">
            <div style="width: 80px;text-align: center;position: relative;">
                <img :src="chong" style="position: absolute;width: 20px;height: 20px;left: 0;" >
                <img :src="schoolLogo" style="width: 60px;height: 60px;"/>
            </div>
            <div style="flex: 1;">
                <div>
                    <sapn style="font-size: 18px;color: #333;">志愿表记录1</sapn>
                    <sapn style="padding: 0 10px;">不限地区</sapn>
                    <sapn>不限类型</sapn>
                </div>
                <div>
                    <span>2018-07-23</span>
                    <span style="padding: 10px;">17:55:09</span>
                </div>
            </div>
            <div>
                <a-icon type="right" class="icon"></a-icon>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "myVolunteerList",
        data(){
            return {
                chong:require("../../../assets/my/volunteer/chong.png"),
                wen:require("../../../assets/my/volunteer/wen.png"),
                bao:require("../../../assets/my/volunteer/wen.png"),

                schoolLogo:require("../../../assets/my/volunteer/school-logo.png"),
            }
        }
    }
</script>

<style scoped>

    .myVolunteerList{
        width: 100%;
        height: 100%;
        font-size: 12px;
    }

    .icon{
        font-size: 23px;
    }
</style>