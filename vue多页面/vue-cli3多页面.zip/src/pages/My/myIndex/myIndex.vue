<template>
    <div class="myIndex">
        <div class="wrapper">
            <div>
                <div class="wave-svg-shape">
                    <svg  xmlns="http://www.w3.org/2000/svg" id="738255fe-a9fa-4a5e-963a-8e97f59370ad" data-name="3-waves" viewBox="0 0 600 215.43">

                        <g class="wave-svg2">
                            <path class="871c1787-a7ef-4a54-ad03-3cd50e05767a" d="M639,986.07c-17-1-27.33-.33-40.5,2.67s-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06S456,987.07,439,986.07s-27.33-.33-40.5,2.67-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06S256,987.07,239,986.07s-27.33-.33-40.5,2.67-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06v205.06h600V996S656,987.07,639,986.07Z" transform="translate(-76 -985)"></path>
                        </g>
                        <g class="wave-svg">
                            <path class="871c1787-a7ef-4a54-ad03-3cd50e05767a" d="M639,986.07c-17-1-27.33-.33-40.5,2.67s-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06S456,987.07,439,986.07s-27.33-.33-40.5,2.67-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06S256,987.07,239,986.07s-27.33-.33-40.5,2.67-24.58,11.84-40.46,15c-13.56,2.69-31.27,2.9-46.2,1.35-17.7-1.83-35-9.06-35-9.06v205.06h600V996S656,987.07,639,986.07Z" transform="translate(-76 -985)"></path>
                        </g>
                    </svg>

                </div>
            </div>
            <!--css3实现波纹-->

        </div>
        <div class="myInfo">
            <div  style="text-align: center;display: flex;flex-direction: row;justify-content: center;align-items: center;color: #333;">
                <div style="flex: 1;">
                    <div>
                        <img :src="message" style="width: 50px;height: 50px;"/>
                    </div>
                    <div>我的消息</div>
                </div>
                <div style="flex: 1;">
                    <div>
                        <img :src="avatar" style="width: 80px;height: 80px;"/>
                    </div>
                    <div>
                        <div>赵丽颖</div>
                        <div style="color: #666">筠连中心</div>
                    </div>
                </div>
                <div style="flex: 1;">
                    <div>
                        <img :src="vip" style="width: 50px;height: 50px;"/>
                    </div>
                    <div>我的级别</div>
                </div>
            </div>
            <div style="padding-bottom: 15px;">
                <div style="text-align: center;display: flex;justify-content: center;padding: 5px 0;">
                    <div style="line-height: 21px;width: 100px;">581分</div>
                    <div style="line-height: 21px;width: 100px;">文科<a-icon type="edit" style="color:#0099ff;"/></div>

                    <div style="position: relative;width: 100px;" >
                        <div @click="showDropDown()">
                            本一 <a-icon type="down" style="color:#0099ff;"/>
                        </div>
                        <div class="drop-down" v-show="dropDownShow">
                            <div style="padding: 3px 0;" @click="chooseItem(0)">1</div>
                            <div style="padding: 3px 0;" @click="chooseItem(0)">1</div>
                        </div>
                    </div>
                </div>
                <div style="font-size: 10px;color: #666;text-align: center;z-index: 10;">
                    修改说明：每个VIP账号分数和文理科类型只能更改2次
                </div>
            </div>

            <div style="height: 20px;background: #f2f2f2;"></div>
            <div style="padding: 15px;">
                <div style="font-size: 20px;padding-bottom: 10px">我的</div>
                <div style="border-bottom: 1px solid #f2f2f2;">
                    <div style="display: flex;align-items: center;border-top: 1px solid #f2f2f2;" v-for="item in myList">
                        <div style="padding:10px 10px 10px 0;">
                            <img :src="item.src" style="width: 26px;height: 26px;"/>
                        </div>
                        <div style="font-size: 16px;">{{item.name}}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "myIndex",
        data(){
            return {
                dropDownShow:false,

                message:require("../../../assets/my/index/message.png"),
                avatar:require("../../../assets/my/index/avatar.png"),
                vip:require("../../../assets/my/index/VIP.png"),

                myList:[
                    {
                        name:"我能上的学校",
                        src:require("../../../assets/my/index/iCanSchool.png")
                    },
                    {
                        name:"我能上的专业",
                        src:require("../../../assets/my/index/iCanMajor.png")
                    },
                    {
                        name:"志愿表",
                        src:require("../../../assets/my/index/myVolunteer.png")
                    },
                    {
                        name:"权限说明",
                        src:require("../../../assets/my/index/myPermission.png")
                    }
                ],

            }
        },
        methods:{
            showDropDown(item) {
                // 点击选项时默认不会关闭菜单，可以手动关闭
                this.dropDownShow = true;
            },
            chooseItem(item){
                this.dropDownShow = false;

            }
        }
    }
</script>

<style scoped>
    .myIndex{
        width: 100%;
        height: 100%;
        position: relative;
        font-size: 14px;
        overflow: hidden;
    }

    .myInfo{
        position: absolute;
        top:60px;
        z-index: 6666666;
        width: 100%;
    }

    .drop-down{
        position: absolute;
        background: white;
        width: 100%;
        box-shadow:0 3px 3px #999;
    }

    /*css3波纹*/
    .wrapper{
        transform:rotateX(180deg);
    }
    .wrapper > div {
        width: 160%;
        height: 135px;
        overflow: hidden;
        display: block;
        margin: 0 auto;
        position: relative;
    }
    .wave-svg-shape {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        overflow: hidden;
        z-index: 1;
    }
    .wave-svg-shape .wave-svg {
        width: 100%;
        height: 100%;
        overflow: hidden;
        fill: rgba(0,153,255,0.75);
        margin: 0;
        animation: waveSvgAnim 2.5s linear infinite;
    }
    .wave-svg-shape .wave-svg2 {
        width: 100%;
        height: 100%;
        overflow: hidden;
        fill: rgba(153,204,255,0.75);
        margin: 0;
        animation: waveSvgAnim 3s linear infinite;
    }
    @keyframes fillUpSvg {
        0% {
            transform: translateY(calc(100px/2)) scaleY(0);
        }
        50% {
            transform: translateY(0) scaleY(1);
        }
        100% {
            transform: translateY(calc(100px/2)) scaleY(0);
        }
    }
    @keyframes waveSvgAnim {
        0% {
            transform: translateX(calc(-100px * 2));
        }
        100% {
            transform: translateX(100px * 2);
        }
    }

    .left{
        float: left;
        width: 33.33333%;
    }

    .clear:after{
        content: " ";
        display: block;
        clear: both;
    }

</style>