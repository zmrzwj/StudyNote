import Vue from 'vue'
import App from './myIndex.vue'


import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css'
import '../../../public/css/public.css'

Vue.use(Antd)


Vue.config.productionTip = false

new Vue({

  render: h => h(App)
}).$mount('#app')
