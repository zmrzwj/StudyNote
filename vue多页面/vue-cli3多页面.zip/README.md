# mutil_page_vue3

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```
```
多页面时访问非index.html页面直接，如home.html,http://localhost:8080/home.html
```
```
建议在开发时，新建一个src/pages目录统一管理，页面的 主js,模版html,主vue页面
```

```
如果不想自己每添加一个页面就修改一次vue.config.js
那就在vue.config.js中使用：
const utils  = require('./utils/utils');

module.exports = {
    baseUrl: './',
    pages: utils.getPages()
}
```



